<?php
echo "saved successfully";
echo htmlspecialchars($_POST['data']);

$fd=fopen("testfile.txt",'w') or die("can't open file");
fwrite($fd,$_POST['data']);
echo "123";
fclose($fd);
?>
