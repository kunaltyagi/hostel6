Thank you for Using Sixteen Wordpress Theme.

	i) Sixteen Wordpress Theme is Based on the Underscores Framework http://underscores.me/, (C) 2012-2013 Automattic, Inc. 
	ii) Sixteen has been created Rohit Tripathi. You can Follow me on http://github.com/rohitink.
	iv) It comes GNU General Public License. More Details about the License can be found in the license.txt file included in the theme.
	
## Copyrights for Resources used in this theme.

	i) Social icons located in the 'images' folder, are under GPL v2 License have been created by me. More details http://rohitink.com/sociocons/
	ii) This theme uses nivoSlider, which is under the MIT License. More details: 
	        http://nivo.dev7studios.com
	   		http://www.opensource.org/licenses/mit-license.php
	iii) For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. http://wptheming.com/options-framework-theme/
	iv) I have used 1 External font from Google Webfonts: Roboto. which are under SIL Open Font License v1.1.
	iv) The files options-custom.js, color-picker.js and media-uploader.js present in the "/js" Folder are part of the "Options Framework", and are under GPL v2.
	v) custom.js has been created by me and under GPL v2.
	vi) skip-link-focus-fix.js, navigation.js, customizer.js & keyboard-image-navigation.js are part of the Underscores Framework used by the theme, and hence under GPL v2.
	vii) The images overlay, dthumb have been created by me for the purpose of this theme. 2cl and 2cr are part of Options framework and are under GPL license.
	viii) The files in the css/ folder are a part of nivoSlider and under MIT license.
	ix) The Timeago Plugin used in this theme is under the MIT License. http://timeago.yarp.com/
	x) Default Background image tigerturle.jpg by http://pixabay.com/en/tiger-and-turtle-duisburg-52691 License: CC0 Public domain.
Everything else used in this theme has been created by me, especially for Sixteen theme and is distributed under GPL license.
	
	
	For any help you can mail me at rohit[at]rohitink.com