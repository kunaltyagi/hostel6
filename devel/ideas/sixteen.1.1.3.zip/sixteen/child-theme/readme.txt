If you are planning to make modifications to this theme, we recommend using child themes. This will make sure that you do not loose your changes with theme updates.

http://codex.wordpress.org/Child_Themes

We have already included a child theme in this folder. You can go ahead and install it directly, and start making modifications safely.